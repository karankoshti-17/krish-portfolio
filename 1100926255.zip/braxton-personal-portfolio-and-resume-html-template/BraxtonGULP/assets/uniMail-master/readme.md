<h2>Universal PHP Mail Feedback Script</h2>

<h3>How to use uniMail</h3>

<ol>
	<li>Connect <code>script.js</code> file to your project and Specify location <code>mailPath</code> in this file</li>
	<li>Add <code>uniForm</code> class to the desired <code>&lt;form&gt;</code> tags in HTML (like index.html example)</li>
	<li>Add <strong>Hidden Required Fields</strong> to your forms in HTML (like index.html example)</li>
	<li>Add any set of fields to your forms in HTML (like index.html example)</li>
	<li>Done!</li>
</ol>
